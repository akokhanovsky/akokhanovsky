                           *** SNOWTRAN***
			   
			   Version 1.1
			   10.10.2023
			   
			   A.A. Kokhanovsky
			   kokhanovsky2023@gmail.com
			   

The FORTRAN code snowtran.f is aimed at the calculation of TOA reflectance in the spectral range 320-2460nm

One needs to install gfortran in ubuntu using the following command:
sudo apt-get install gfortran

The next step is to create snowtran.exe using the following command:
gfortran -o snowtran.exe snowtran.f

The code can be run using the following command
./snowtran.exe

The output file snowtran.dat contains three columns:
wavelength (nm), top-of-atmosphere reflectance, bottom-of-atmosphere reflectance

There are three input files:
1) ice_refr_index.dat
2) absorption_spectra_gases.dat
3) input_snowtran.dat

The file 'ice_refr_index.dat' consists of 3 columns (wavelength(microns), real part of ice refractive index,imaginary part of ice refractive index).
This files should not be modified.
The file 'absorption_spectra_gases-dat' contains 9 columns: 1-wavelength (nm), 2-water vapor absorption coefficient (1/cm),columns 3,4,5 - parameters for teh estimation of the water vapor transmittance, 6 - ozone cross section (cm*cm/molec), 7- oxygen absorption coefficient (1270nm band is excluded)(1/cm), 8- NO2 absorption coefficient, 9- CO2 absorption coefficient
The last two columns are not used in the current version of the algorithm.



The file 'input_snowtran.dat' contains 5 lines with the following meaning:

1)average temperature (K), average pressure (hPa), surface pressure (hPa), surface height (m), total ozone (DU), precipitable water vapour (cm), normalized molecular oxygen O2 vertical column (cm)
220. 400.  800.  100.   220. 0.04 0.5
2)solar zenith angle, viewing zenith angle, solar azimuthal angle, viewing azimuthal angle (in degrees)
63.61  20.63  54.14 -64.25
3)diam_upper_layer(mm),diam_lower_layer(mm),optical thickness of upper layer,concentration of impurities(ppm), Impurity_absorption_coefficient(normalized),Angström parameter(impurities in snow),reflectance_of_a_semi_infinite_snow_layer    (0.96 - default)
0.09  0.3  5.0    0.    0.     4.   0.95728
4)AOT(550nm), Angström coefficient (aerosol)   (0.02 1.0 - default)
0.01 1.0
5)molecular extinction model, surface pressure model (0 0 - default)
0 0
*************************************
Comments to the last input line:
1a
switch for the molecular optical thickness (MOT)= 0 (then the specific equation for the MOT at DOME C is used);
switch for the molecular optical thickness (MOT)= 1 (then the general equation for the spectral MOT is used);
1b
if the second switch is equal to zero, the site pressure is estimated from the exponential dependence using scale height of 6km;
if the second switch is equal to 1, the site surface pressure is taken from line 1



The output file 'output_snowtran_grid_1nm_for_checkup.dat' corresponds to the input file 'input_snowtran_grid_1nm_for_checkup.dat'






The output can be plotted using, e.g., gnuplot

sudo apt-get install gfortran
gnuplot
call 'plot.sh'


The test calculation together with the experimentally measured spectrum (see 'exp.dat' file)
is shown in the figure

The figure can be saved as fig.png and viewed as
feh fig.png
